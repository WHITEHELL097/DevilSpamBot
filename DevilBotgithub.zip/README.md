<h1 align="center"><b>😈 𝙏𝙝𝙚𝘿𝙚𝙫𝙞𝙡𝙎𝙥𝙖𝙢 🔥💫 😈</b></h1>

<h4 align="center"> 𝐀 𝐏𝐎𝐖𝐄𝐑𝐅𝐔𝐋 𝐒𝐏𝐀𝐌𝐁𝐎𝐓𝐒</h4>

<p align="center"><a href="https://t.me/whitehell097"><img src="https://telegra.ph//file/4dc15eb9557d661270a58.jpg" width="400"></a></p>


> ⭐️ Thanks to everyone for using THIS OP DEVIL SPAM BOT, That is the greatest pleasure we have !

<br>

- ⚠️ Do not forget to fork this repo. Else error can occur in deployment.

# ᴅᴇᴘʟᴏʏᴍᴇɴᴛ


<details>
<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ʜᴇʀᴏᴋᴜ</b></summary>
<br>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/WHITEHELL097/DevilBotSpam)
  
</details>


<details>
<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ᴋᴏʏᴇʙ</b></summary>
<br>

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=&branch=name&name=thedevilspam)
  
</details>


# Rᴇǫᴜɪʀᴇᴍᴇɴᴛs

- `10 BOT-TOKENS`

- `OWNER-ID`


# ꜱᴜᴘᴘᴏʀᴛ ✨
<a href="https://t.me/devilz_support"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>
